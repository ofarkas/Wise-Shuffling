/**
 * 
 */
package permutations;

import java.util.ArrayList;
import java.util.Random;

import examiner.ScoredSequences;
import examiner.SeqScore;

/**
 * @author farkas
 *
 */
public class SeqPermutations {
    String orig = "";
    private ScoredSequences permutationList = new ScoredSequences(true);
    private int allPermutationsLimit = 100000;
    private Random r = new Random();

    public SeqPermutations(String orig, int limit) {
        super();
        this.orig = orig;
        this.allPermutationsLimit=limit;
                if(dfactorial(orig.length())<=limit) {
                    System.out.println("All permutations will be created:"+dfactorial(orig.length())+"<"+limit);
                } else {
                    System.out.println("Number of permutations is limited to:"+limit);
                }
    }
    
    public void permute() {
        int n=orig.length();
        if(dfactorial(n)<=allPermutationsLimit) {
            allPermutations(orig,null);
        } else {
            randomPermutations();
        }
        return;
    }
    
    private void randomPermutations() {
        for (int k = 0; k < allPermutationsLimit; k++) {
            int siz = orig.length();
            ArrayList<Integer> nums = new ArrayList<Integer>(siz);
            int[] numA = new int[siz];
            for (int i = 0; i < siz; i++) {
                nums.add(i);
            }
            int j = 0;
            int rn = 0;
            for (int i = siz; i > 0; i--) {
                rn = r.nextInt(i);
                numA[j] = nums.remove(rn);
//                nums.remove(rn);
                j = j + 1;
            }
            String res = "";
            for (int i = 0; i < numA.length; i++) {
                j = numA[i];
                res += orig.charAt(j);
            }
            SeqScore resSeq = new SeqScore();
            resSeq.setSeq(res);
            if (!permutationList.contains(resSeq))
                permutationList.add(resSeq);
            System.out.print("\r"+k);
        }
    }
        
        private void allPermutations(String s, ArrayList<Character> as) {
            if(as==null) {
                as=new ArrayList<Character>(s.length());
                for (int i = 0; i < s.length(); i++) {
                    as.add(s.charAt(i));
                }
                s="";
            }
            if(as.size()==1) {
                s+=as.get(0);
                SeqScore resSeq=new SeqScore();
                resSeq.setSeq(s);
//                if(!permutationList.contains(resSeq)) permutationList.add(resSeq);
                permutationList.add(resSeq);
//                System.err.print(resSeq.getSeq()+"|");
                return;
            }
            for (int i = 0; i < as.size(); i++) {
                ArrayList<Character> as2 = CopyOf(as);
                char c = as.get(i);
                String s2=s+c;
                as2.remove(i);
                allPermutations(s2, as2);
            }
        }
        
    public ScoredSequences getPermutationList() {
        if(permutationList.size()==0) {
            permute();
        }
        return permutationList;
    }

    public String getOrig() {
        return orig;
    }

    public void setOrig(String orig) {
        if(!this.orig.equalsIgnoreCase(orig)) {
            permutationList.clear();
        }
        this.orig = orig;
    }

    public int getAllPermutationsLimit() {
        return allPermutationsLimit;
    }

    private ArrayList<Character> CopyOf(ArrayList<Character> as) {
        ArrayList<Character> as2 = new ArrayList<Character>(as);
        return as2;
    }

    private double dfactorial(int n) {
        double res = 1.0;

        for (int i=1 ; i<n; i++) {
            res=res*(i+1);
        }
        return res;
    }

    
}