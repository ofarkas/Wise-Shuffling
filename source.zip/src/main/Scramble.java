package main;

import java.io.FileNotFoundException;
import java.util.Iterator;

import javax.swing.JOptionPane;

import config.Config;
import examiner.CheckSequence;
import examiner.PepSeqLookUp;
import examiner.ScoredSequences;
import examiner.SeqScore;
import examiner.Sort;
import examiner.Sortable;
import static java.lang.Math.round;
import permutations.SeqPermutations;
import window.TextOutputWindow;

//@WebServlet("/Scramble")
public class Scramble {
	private boolean running;
	/**
	 * @return the running
	 */
	public boolean isRunning() {
		return running;
	}
	private boolean dist = false;
	private static class Distribution {
		int[] distnumbers = null;
		int[] bins = null;
		@Override
		public String toString() {
			String distOut="";
			for (int i = 0; i < distnumbers.length; i++) {
				if(i==0) {
					distOut+=bins[i];
				} else {
					distOut+=bins[i]+1;
				}
				if((i+1)<bins.length) {
					distOut+="-"+bins[i+1];
				}
				distOut+="]\t";
				distOut+=distnumbers[i]+"\n";
			}
			return distOut;
		}
	}

	private boolean hasValidResults = false;
	private ScoredSequences finalResults=null;
	private Config config=null;
	/**
	 * @return the finalResults
	 */
	public ScoredSequences getFinalResults() {
		return finalResults;
	}

	/**
	 * @param hasValidResults the hasValidResults to set
	 */
	public void setHasValidResults(boolean hasValidResults) {
		this.hasValidResults = hasValidResults;
	}

	/**
	 * @param pepSeq the pepSeq to set
	 */
	public void setPepSeq(String pepSeq) {
		this.pepSeq = pepSeq;
	}

	/**
	 * @param doConfig the doConfig to set
	 */
	public void setDoConfig(boolean doConfig) {
		this.doConfig = doConfig;
	}

	/**
	 * @param psl the psl to set
	 */
	public void setPsl(PepSeqLookUp psl) {
		this.psl = psl;
	}

	String pepSeq;
	boolean doConfig=false;
	PepSeqLookUp psl = null;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Scramble() {
		super();
		dist=Shuffling.dist;
	}

//	public static void main(String[] args) {
//
//		new Scramble().doScramble(new Config(), args[0]);
//	}

	public void doScramble(Config config, String seq) {
		if(isRunning()) {
			JOptionPane.showMessageDialog(null, "DoScramble is already running, please wait \'till it ends.");
			return;
		}
		running=true;
		this.config=config;
		hasValidResults=false;
		if(seq==null) {
			return;
		}
		seq=seq.toUpperCase();
		TextOutputWindow out=null;
		try {
			out = new TextOutputWindow();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		out.println("Enter doScramble.");
		out.println("The sequence to scramble is:" + seq);
		out.println("Read the config file in ReadConfig.");
		// Read config file
		out.println("The actual configuration is:");
		if(doConfig) {
			out.println("Do manual configuration.");
		}
		////            if(request.getParameter("reverse")!=null) {
		////                config.setReverseMode(true);
		////                if(request.getParameter("reverse")!=null) {
		out.println("After ReadConfig...");
		out.println(config.toString());
		config.writeConfig();
		// Check the parameters
		out.println("The sequence to scramble is:" + seq);
		out.println("Configuration is from file: "+config.getID());
		// Check the original sequence
		SeqScore sc = new SeqScore();
		sc.setSeq(seq);
		CheckSequence check = new CheckSequence(sc, config);
		check.check(sc);
		out.println("Scores for the original sequence are:");
		out.println("Motif self-similarity penalty: "+sc.getScores().get(SeqScore.MOTIF));
		out.println("Motifs to avoid penalty: "+sc.getScores().get(SeqScore.PAIRS));
		out.println("Hydrophobicity penalty: "+sc.getScores().get(SeqScore.HIDROPHOBIC));
		if(config.isNetworked()) {
			out.println("Start sequence lookup.");
			if (psl == null) {
				out.println("Create new lookup class.");
				psl = new PepSeqLookUp(seq);
				if (psl == null) {
					out.println("Creation failed...");
					//                    System.exit(1);
				}
			} else {
				out.println("Set sequence for lookup.");
				psl.setSeq(seq);
			}
			out.println("Execute lookup.");
			if (psl == null) {
				out.println("Creation failed #2...");
				//                System.exit(1);
			}
			int n=psl.lookup(config);
			out.println("Lookup finished.");
			if(n>0) {
				out.println("Your sequence("+seq+") was found in \"UniprotKB\".");
			} else {
				out.println("Your sequence ("+seq+") was NOT found in \"UniprotKB\".");
				if(n==-1) {
					out.println("Local database lookup for sequence ("+seq+") failed, so it is turned off.");
					config.setNetworked(false);
				}
			}
		}

		//            response.flushBuffer();
		out.println("Start peptide SCRAMBLE according to current configuration. Please wait.");
		//            response.flushBuffer();
		SeqPermutations sp = new SeqPermutations(seq,config.getNumberOfTrials());
		ScoredSequences permutations = (ScoredSequences) sp.getPermutationList();
		//            ArrayList<SeqScore> permutations=sp.getPermutationList();
		ScoredSequences remaining = new ScoredSequences(!config.isReverseMode());
		//            ArrayList<SeqScore> remaining= new ArrayList<SeqScore>();
		remaining.addAll(permutations);
		//            response.flushBuffer();
		CheckSequence cs = new CheckSequence(sc, config);
		int i = 0;
		out.println("Start with "+remaining.size()+" sequences.");
		boolean doCharge=cs.doCharge;
		if(doCharge) {
			out.println("Turn on check for charge distribution.");
		} else {
			out.println("Turn off check for charge distribution due to no present charges.");
		}
		System.out.println();
		System.out.println("Scoring...");
		//            response.flushBuffer();
		out.print("|");
		//            response.flushBuffer();
		while(i<remaining.size()) {
			//                out.print("\r"+i);
			//                response.flushBuffer();
			cs.check(remaining.get(i));
			//                String tmp = remaining.get(i).getSeq();
			//                if(ccp.hasCommonPos(tmp)) {
			////                    SeqScore rem=remaining.remove(i);
			i=i+1;System.out.print("\r"+i);
			
		}
		out.println("Scoring finished.");
		System.out.println("Scoring finished.");
		System.out.println("Reverse parameter is: "+config.isReverseMode());
		boolean filter = !config.getPairsToFilter().isEmpty();
		if(filter) {
			out.println("MOTIF FILTERING IS ACTIVE.");
		}
		//            response.flushBuffer();
		if(remaining.size()<1) {
			out.println("NO SUITABLE PERMUTATION FOUND.");
			//                response.flushBuffer();
		} else {
			Sort sort = new Sort((Sortable) remaining);
			ScoredSequences res = (ScoredSequences) sort.getResult();
			if(dist) {
				out.println("Sequence distribution with respect to scores:");
				out.print(getDistribution(res).toString());
			}
			//                response.flushBuffer();
			//                        Check the sequences and remove duplicates
			System.out.println("Distribution:");
			for(i=0;i<res.getLength();i=i+res.getLength()/100) {
				System.out.println((i+1)+"\t"+res.get(i).getSum());
			}
            int median=0;
            int nn=res.size();
            if(nn>=3) {
                if((nn/2*2)==nn) {
                        median=(res.get(nn/2-1).getSum()+res.get(nn/2).getSum())/2;
                } else {
                        median=res.get(nn/2).getSum();
                }
			}
			out.println("The median `value of the penalty scores is: "+median+", the maximum is: "+res.get(nn-1).getSum());
			out.println("Please, examine the following suitable permutations:");
			i=0;
			finalResults=new ScoredSequences(!config.isReverseMode());
			ScoredSequences webFound=new ScoredSequences(!config.isReverseMode());
			//                        while(res.size() < Math.min(res.size(), config.getPrintLength())) {
			while(finalResults.size() < Math.min(res.size(), config.getPrintLength())) {
				if(i>=res.size()) {
					break;
				}
				SeqScore pout = res.get(i);
				if(finalResults.contains(pout)) {
					i++;
					continue;
				}
				if(filter) {
					if(cs.isFiltered(pout)) {
						out.println("Filter out:"+pout.getSeq()+"("+pout.getSum()+")");
						i++;
						continue;
					}
				}
				if(config.isNetworked()&&(pout.getScores().get(SeqScore.DATDET)==0)) {
					psl.setSeq(pout.getSeq());
					int n=psl.lookup(config);
					if(n>0) {

						//                                    SeqScore rem=remaining.remove(i);
						//                                    out.print("W-"+rem.getSeq()+"("+rem.getSum()+") | ");
						out.print("W-"+pout.getSeq()+"("+pout.getSum()+") | ");
						//                        response.flushBuffer();
						webFound.add(pout);
						check.addNetPenalty(pout);
						res.set(i,pout);
						for (int j = i; j < res.getLength()-1; j++) {
							if(!res.test(j, j+1)) {
								//                                            test returns false if element j is larger than element (j+1) 
								res.swap(j, j+1);
								continue;
							} else {
								while((j<res.getLength()-1)&&(res.get(j).getSum()==res.get(j+1).getSum())) {
									if(res.test(j, j+1)&&res.get(j).getSeq().equals(res.get(j+1).getSeq())) {
										//                                                    The two elements are the same, so remove the duplicate
										res.remove(j+1);
									}
									j++;
								}
								continue;
							}
						}
//						CFO WARNING!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
//						Sort srt = new Sort((Sortable) res);
//						res = (ScoredSequences) srt.getResult();
						continue;
					}
				}
				i++;
				String print=pout.getSeq()+" ("+pout.getSum()+")"
						+ "(Self:"+pout.getScores().get(SeqScore.MOTIF)+")"
						+ "(Motif:"+pout.getScores().get(SeqScore.PAIRS)+")"
						+ "(Hydro:"+pout.getScores().get(SeqScore.HIDROPHOBIC)+")"
						+ "(Vol:"+pout.getScores().get(SeqScore.VOLUME)+")";
				if(doCharge) print += "(Charge:"+pout.getScores().get(SeqScore.CHARGE)+")";
				if(config.isNetworked()) print += "(DB:"+pout.getScores().get(SeqScore.DATDET)+")";
				out.println();
				out.println(print);
				finalResults.add(pout);
				//                        response.flushBuffer();
			}
			if(res.size()==0) {
				out.println();
				out.println("Sorry, no scrambled sequence survived the final database check.");
			}
			if(!Shuffling.clm) out.println("CLOSE THE OUTPUT WINDOW TO CONTINUE.");
			hasValidResults=true;
			System.out.println("Result size is:"+finalResults.getLength());
			String reslist = "";
			reslist="Configuration name:\t"+getConfig().getID()+"\n";
			reslist+="Sequence to shuffle:\t"+getConfig().getSeq()+"\n";
			reslist+="Median penalty score is\t"+median+"\n";
			reslist+="WISESHUFFLING application suggests the following scrambled sequences:\n";
			if(res.getLength()<1) {
				reslist+="No suitable results found, try to disable database search in the configuration.\n";
			} else {
				int ind = 1;
				for (Iterator<SeqScore> iterator = finalResults.iterator(); iterator.hasNext();) {
					SeqScore seqScore = iterator.next();
					reslist+=seqScore.getSeq()+"\t"+seqScore.getSum()+"\n";
					ind++;
					if(ind>Math.min(finalResults.size(),config.getPrintLength())) {
						break;
					}
				}
			}
			System.out.println(reslist);
			System.out.println("Set results into config in DoScramble.");
			config.setResults(reslist);
			config.writeConfig();

			if(getFinalResults()==null) {
				System.out.println("Nobazdmeg. (Child in time...)");
			}
			//                for (Iterator<SeqScore> iterator = remaining.iterator(); iterator.hasNext();) {
			//                    String string = (String) iterator.next().getSeq();
			//                    out.println(string);
		}
		running=false;            
	}

	public ScoredSequences getResults() {
		while(!hasValidResults) {
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		if(finalResults==null) {
			System.err.println("Scramble results internal error found.");
		} 
		return finalResults;
	}

	boolean hasResults() {
		return hasValidResults;
	}

	/**
	 * @return the config
	 */
	public Config getConfig() {
		return config;
	}

	private Distribution getDistribution(ScoredSequences s) {
		Distribution d=new Distribution();
		int len=10;
		d.distnumbers=new int[len];
		d.bins=new int[len+1];
		int n=s.getLength();
		int low=s.get(0).getSum();
		int high=s.get(n-1).getSum();
		int wide=high-low;
		double step=wide/len;
		System.out.println("Step lenth in getDist... is "+step);
		System.out.println("Result lenth is "+n);
		for (int i = 0; i <= len; i++) {
			d.bins[i]=(int) round(low+i*step);
		}
		for (int i = 0; i < n; i++) {
			int rs=s.get(i).getSum()-low;
			int ind = (int) round(rs/step);
			if(ind<d.distnumbers.length) d.distnumbers[ind]++;
		}
		d.bins[10]=(int) round(low+10*step);

		return d;
	}

}
