package main;

import java.io.File;

import javax.swing.UIManager;

import config.ArgumentConfig;
import config.Config;
import window.StartWindow;

public class Shuffling {

    //The following variables are due to last minute patching of some features
    public static boolean clm=false;
    public static boolean snl=false;
    public static boolean dist = false;
    
    public static void main(String[] args) throws InterruptedException {
        Config config = new Config();
        File f = new File(config.getID());
        if(f.exists()) {
            config.readConfig(config.getID());
        }
        String origCfg = config.getID();
        String origSeq = config.getSeq();
        ArgumentConfig.arguments(config, args);
        dist=config.distribution;
        if (args!=null && args.length!=0) {
            clm=true;
        }
        String seq = config.getSeq();
        f = new File(config.getID());
        if(f.exists()) {
            config.readConfig(config.getID());
        }
        if(!config.getID().equals(origCfg)) {
            f = new File(config.getID());
            if(!f.exists()) {
                config.writeConfig();
            }
            config.readConfig(config.getID());
            if(!config.getSeq().equals(origSeq)) {
                config.setSeq(seq);
                config.resetResults();
            }
        }
        config.printResults();
        config.writeConfig();
        if(!clm) {
            UIManager.getDefaults().put("TextArea.font", UIManager.getFont("TextField.font"));
            new StartWindow("WISE SHUFFLING 1.0").doit(config);
        } else {
            new Scramble().doScramble(config,config.getSeq());
        }
    }

}