/**
 * 
 */
package window;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

import config.Config;
import main.Scramble;
import resources.ResourceLoader;
import window.documentation.Doksi;

/**
 * @author farkas
 *
 */
public class StartWindow extends JFrame {

    private static final long serialVersionUID = 1L;
	String header;
    String reslist="";
    private Scramble scramble = new Scramble();

    public StartWindow(String header) throws HeadlessException {
        super(header);
        this.header = header;
        setSize(900,370);
        setMinimumSize(new Dimension(900,370));
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }
    
    public void doit(Config config) {
        JPanel jpMain = new JPanel();
        jpMain.setLayout(new BorderLayout());
        JLabel jphead=null;
        jphead = new JLabel(new ImageIcon(ResourceLoader.loadImage("logo.png").getScaledInstance(900,300,Image.SCALE_SMOOTH)));
        jphead.setSize(900,300);
        jpMain.add(jphead,BorderLayout.NORTH);
        JPanel qp = new JPanel(); 
        JButton qb = new JButton("QUIT");
        qb.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
                setVisible(false);
            }
            
        });
        qp.add(qb);
        jpMain.add(qp,BorderLayout.SOUTH);
        JPanel jpc = new JPanel();
        jpc.setLayout(new GridLayout(2,4));
        JLabel jlconf=new JLabel("Configuration file name:");
        JLabel jlcn = new JLabel(config.getID());
        JLabel jseqL=new JLabel("Sequence to shuffle:");
        JLabel jseq = new JLabel(config.getSeq());
        
        JButton jbconf = new JButton("CONFIGURE");
        jbconf.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                Thread ct = new Thread(new Runnable() {

                    @Override
                    public void run() {
                        new ConfigWindow("WISE SHUFFLING CONFIGURATION").manualConfig(config);
                        jlcn.setText(config.getID());
                        jseq.setText(config.getSeq());
                    }
                });         
                ct.start();
            }
            
        }
        );
        JButton jbdoc = new JButton("M A N U A L");
        jbdoc.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                Thread ct = new Thread(new Runnable() {

                    @Override
                    public void run() {
                        String text = ResourceLoader.loadText("manual.txt");
                        Doksi d = new Doksi("WISE SHUFFLING MANUAL");
                        d.showDoc(text);
                    }
                });         
                ct.start();
            }
            
        }
        );
        JButton jbrun = new JButton("START SHUFFLING");
        jbrun.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e2) {
                reslist="";
                Thread rt = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        System.out.println("Hi! I start shuffling... (Ramble on..)");
                        scramble.doScramble(config, config.getSeq());
                        if(scramble.getFinalResults()==null) {
                            System.out.println("Ajjaj... Smoke on the water...");
                        } else {
                        }
                    }
                });         
                rt.start();
            }
            
        }
        );
        JButton jbres = new JButton("SHOW RESULTS");
        jbres.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e2) {
                Thread rest = new Thread(new Runnable() {

                    @Override
                    public void run() {
                        System.out.println("Hi! I'm getting the results. (Paranoid..)");
                        if(config.getResults()!=null) {
                            reslist=config.getResults();
                        } else {
                            reslist="";
                        }
                        if(reslist.isEmpty()) {
                            System.out.println("No actual results found, rerun SCRAMBLE (Vadászok gyülekezője...)");
                        } else {
                            showResults(config);
                            return;
                        }
                        if(scramble.getFinalResults()==null) {
                            scramble.doScramble(config, config.getSeq());
                        }
                        config.writeConfig();
                        showResults(config);                   
//                        reslist = "";
//                        reslist="Configuration name:\t"+scramble.getConfig().getID()+"\n";
//                        reslist+="Sequence to Shuffle:\t"+scramble.getConfig().getSeq()+"\n";
                    }
                });         
                rest.start();
            }
            
        }
        );
        jpc.add(jlconf);
        jpc.add(jlcn);
        jpc.add(jseqL);
        jpc.add(jseq);
        jpc.add(jbconf);
        jpc.add(jbdoc);
//        jpc.add(new JLabel());
        jpc.add(jbrun);
        jpc.add(jbres);
        jpMain.add(jpc,BorderLayout.CENTER);
//        jpMain.setLayout(new BorderLayout(10,10));
        jpMain.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(jpMain);
        setSize(900,440);
        setMinimumSize(new Dimension(900,440));
        setMaximumSize(new Dimension(900,440));
        setVisible(true);
        waitForFrame();
    }
    
    private void showResults(Config config) {
        if(config.getResults()!=null) {
            reslist=config.getResults();
        } else {
            JOptionPane.showMessageDialog(this, "No results found, please, shuffle.");
            return;
        }
        JFrame resF =new JFrame("RESULTS");
        JPanel jp = new JPanel();
        JTextArea jt = new JTextArea(reslist);
        jp.add(jt);
        resF.add(jp);
        resF.setSize(430,250);
        resF.setMinimumSize(new Dimension(430,250));
        resF.setVisible(true);
        System.out.println(reslist);
    }
    
    private void waitForFrame() {
        while(isVisible()) {
            try {
                java.lang.Thread.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.exit(0);
    }

}