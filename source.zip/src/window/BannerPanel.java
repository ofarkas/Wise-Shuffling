
package window;

import javax.swing.*;
import java.awt.*;
import java.net.URL;

public class BannerPanel extends JPanel {
    private static final long serialVersionUID = 1L;
	private Image backgroundImage;

    public BannerPanel() {
        URL logoUrl = getClass().getResource("/resources/images/logo.png");
        if (logoUrl != null) {
            ImageIcon icon = new ImageIcon(logoUrl);
            backgroundImage = icon.getImage();
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(800, 200); // Suggested banner size
    }
}
