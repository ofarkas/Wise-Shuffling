package window;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

import config.Config;

public class DefaultWindow extends JFrame implements ActionListener{
    
    private static final long serialVersionUID = 1L;
	JFrame f = new JFrame("WISE SHUFFLING");
    JPanel p = new JPanel();
    ImageIcon i = new ImageIcon("images/ponik.jpeg");

    JFrame frame = null;
    
//    private void play() {
//        frame = new JFrame();
//        JPa
    
    // Main class
    
    public void sumWindow(Config config) {
        f = new JFrame("WISE SHUFFLING");
        JPanel p = new JPanel();
        p.setLayout(new GridLayout(3,2));
        
        
        JLabel jl = new JLabel("Sequence:");
        JTabbedPane tp = new JTabbedPane(4);
        JTextField jt1 = new JTextField("TQTPT");
        jt1.setText("Sequence");
        tp.add(new JTextField(2));
        p.add(jl);
        p.add(jt1);
        p.setVisible(true);
        f.add(p);

        f.setSize(1024,768);
        f.setVisible(true);
        waitForFrame();
    }
    
    public void startWindow() {
        ImageIcon i = new ImageIcon("images/logo.png");
        JLabel l = new JLabel(i);
        l.setSize(new Dimension(900, 300));
        JButton b = new JButton("START WISE SHUFFLING");
        b.addActionListener(this);
        b.setActionCommand("START");
        p = new JPanel();
        p.setBackground(Color.magenta);
        p.setLayout(new BorderLayout(10,10));
        p.add(l,BorderLayout.NORTH);
        p.add(b,BorderLayout.SOUTH);
        f.add(p);
        f.setSize(900,330);
        f.setMinimumSize(new Dimension(900,330));
        f.setVisible(true);
        waitForFrame();
    }
    
    private void waitForFrame() {
        while(f.isVisible()) {
            try {
                java.lang.Thread.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    
    public void closeWindow() {
        f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        f.setVisible(false);
        f.dispose();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getActionCommand().equals("START")) {
            closeWindow();
        }
    }

}