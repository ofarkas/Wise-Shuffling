/**
 * 
 */
package window;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;

import config.Config;
import config.Transform;

/**
 * @author farkas
 *
 */
public class ConfigWindow extends JFrame {
	
    private static final long serialVersionUID = 1L;
	Config config = null;
	private JPanel jpConfig = null;
    JLabel configNameL = null;
    JTextField configName = null;
//    JLabel dirLabel = new JLabel("Current directory:");
//    JTextField dir = new JTextField();
    JLabel seqL = null;
    JTextField seq = null;
    JLabel netL = null;
    JCheckBox net = null;
//    net.setSelected(config.isNetworked());
        JLabel searchProgL = null;
        JTextField searchProg = null;
        JLabel indexDirL = null;
        JTextField indexDir = null;
    JLabel dummyText = null;
    JLabel reverseL = null;
    JCheckBox reverse = null;
//    reverse.setSelected(config.isReverseMode());
    JLabel numTrialL = null;
    JTextField numTrial = null;
    JLabel printLengthL = null;
    JTextField printLength = null;
    JLabel datDecL = null;
    JTextField datDec = null;
    JLabel mot = null;
    JLabel mot2 = null;
    JLabel mot3 = null;
    JLabel mot4 = null;
    JLabel pairsToAvoidL = null;
    JTextField pairsToAvoid = null;
    JLabel pairToAvoidScoreL = null;
    JTextField pairToAvoidScore = null;
    JLabel pairsToFilterL = null;
    JTextField pairsToFilter = null;
//    JLabel pairToFilterScoreL = new JLabel("Penalty:");
//    JTextField pairToFilterScore = new JTextField(Transform.toIntInput(config.getPairToAvoidScore()));
    JLabel smot = null;
    JTextField mot1Score = null;
    JTextField mot2Score = null;
    JTextField mot12Score = null;
    JLabel hyd = null;
//    hyd.setBorder(new LineBorder(getForeground()));
    JLabel hyd2 = null;
    JLabel hyd3 = null;
    JLabel hyd4 = null;
    JLabel hp1L = null;
    JTextField hp1 = null;
    JLabel hp1ScL = null;
    JTextField hp1Sc = null; 
    JLabel hp2L = null;
    JTextField hp2 = null;
    JLabel hp2ScL = null;
    JTextField hp2Sc = null; 
    JLabel hp3L = null;
    JTextField hp3 = null;
    JLabel hp3ScL = null;
    JTextField hp3Sc = null; 
    JLabel charge = null;
    JLabel charge2 = null;
    JLabel charge3 = null;
    JLabel charge4 = null;
    JLabel pos = null;
    JTextField posaas = null;
    JLabel chScore1L = null;
    JTextField chScore1 = null;
    JLabel neg = null;
    JTextField negaas = null;
    JLabel chScore2L = null;
    JTextField chScore2 = null;
    JLabel volL = null;
    JTextField vol = null;
    JButton set = null;
    JButton defaults = null;
    JButton load = null;
    JButton wise = null;
    
    
    public ConfigWindow(String header) {
        super(header);
//        ImageIcon i = new ImageIcon("mages/my_little_pony_hero.jpg");
//        setIconImage((Image)getIconImage());
        setSize(1050,450);
        setMinimumSize(new Dimension(1050,450));
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
//        LayoutManager layout = new GridLayout(0,2);
//        setLayout(getLayout());
    }
    
    public void manualConfig(Config inpconfig) {
        config=inpconfig;
        if(config.getResults()!=null) {
            Object[] options = {"Yes", "No"};
            int n = JOptionPane.showOptionDialog(this,
                    "Previously achived results stored in \n\""+inpconfig.getID()+"\" for sequence: "+inpconfig.getSeq()+"\nwill be deleted from the memory.\n\tContinue?" ,
                    "PLEASE CONFIRM",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null,     //do not use a custom Icon
                    options,  //the titles of buttons
                    options[1]); //default button title
            if(n!=0) {
                return;
            }
        }
        config.resetResults();
        configNameL = new JLabel("Config name:");
        configName = new JTextField(config.getID());
//        JLabel dirLabel = new JLabel("Current directory:");
//        JTextField dir = new JTextField();
        seqL = new JLabel("Original sequence:");
        seq = new JTextField(config.getSeq());
        netL = new JLabel("Local database search:");
        net = new JCheckBox();
        net.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				rePaintPanel();
			}
		});
        net.setSelected(config.isNetworked());
            searchProgL = new JLabel("Path to PeptideMatchCMD_1.1.jar:");
            searchProg = new JTextField(config.getSearchCfg());
            indexDirL = new JLabel("Path to index directory");
            indexDir = new JTextField(config.getIndexCfg());
        dummyText = new JLabel(" ");
        reverseL = new JLabel("Reverse mode (Development)");
        reverse = new JCheckBox();
        reverse.setSelected(config.isReverseMode());
        numTrialL = new JLabel("Maximal number of permutations:");
        numTrial = new JTextField(config.getNumberOfTrials().toString());
        printLengthL = new JLabel("Number of results to output:");
        printLength = new JTextField(config.getPrintLength().toString());
        datDecL = new JLabel("Database detection penalty:");
        datDec = new JTextField(config.getDdp().toString());
        mot = new JLabel("MOTIFS, POSITIONS",SwingConstants.CENTER);
        mot2 = new JLabel();
        mot3 = new JLabel();
        mot4 = new JLabel();
        pairsToAvoidL = new JLabel("Motifs to avoid:");
        pairsToAvoid = new JTextField(Transform.toInput(config.getPairsToAvoid()));
        pairToAvoidScoreL = new JLabel("Penalty:");
        pairToAvoidScore = new JTextField(Transform.toIntInput(config.getPairToAvoidScore()));
        pairsToFilterL = new JLabel("Motifs to filter:");
        pairsToFilter = new JTextField(Transform.toInput(config.getPairsToFilter()));
//        JLabel pairToFilterScoreL = new JLabel("Penalty:");
//        JTextField pairToFilterScore = new JTextField(Transform.toIntInput(config.getPairToAvoidScore()));
        smot = new JLabel("Self-match motif penalties (\"??\",\"?.?\",\"??\"->\"?.?\")");
        mot1Score = new JTextField(Transform.toIntInput(config.getMotif1Score()));
        mot2Score = new JTextField(Transform.toIntInput(config.getMotif2Score()));
        mot12Score = new JTextField(Transform.toIntInput(config.getMotif12Score()));
        hyd = new JLabel("HYDROPHOBICITY",SwingConstants.CENTER);
//        hyd.setBorder(new LineBorder(getForeground()));
        hyd2 = new JLabel();
        hyd3 = new JLabel();
        hyd4 = new JLabel();
        hp1L = new JLabel("Highly hydrophobic amino acids:");
        hp1 = new JTextField(Transform.toInput(config.getHydrophobic1()));
        hp1ScL = new JLabel("Penalty:");
        hp1Sc = new JTextField(config.getHp1Score().toString()); 
        hp2L = new JLabel("Moderately hydrophobic amino acids:");
        hp2 = new JTextField(Transform.toInput(config.getHydrophobic2()));
        hp2ScL = new JLabel("Penalty:");
        hp2Sc = new JTextField(config.getHp2Score().toString()); 
        hp3L = new JLabel("Least hydrophobic amino acids:");
        hp3 = new JTextField(Transform.toInput(config.getHydrophobic3()));
        hp3ScL = new JLabel("Penalty:");
        hp3Sc = new JTextField(config.getHp3Score().toString()); 
        charge = new JLabel("CHARGES",SwingConstants.CENTER);
        charge2 = new JLabel();
        charge3 = new JLabel();
        charge4 = new JLabel();
        pos = new JLabel("Positively charged amino acids:");
        posaas = new JTextField(Transform.posChargeToInput(config));
        chScore1L = new JLabel("Charged/uncharged match penalty:");
        chScore1 = new JTextField(config.getChScore1().toString());
        neg = new JLabel("Negatively charged amino acids:");
        negaas = new JTextField(Transform.negChargeToInput(config));
        chScore2L = new JLabel("Opposite charge match penalty:");
        chScore2 = new JTextField(config.getChScore2().toString());
        volL = new JLabel("VOLUME MISMATCH PENALTY SCALING:",SwingConstants.LEFT);
        vol = new JTextField(config.getVolScale().toString());
        set = new JButton("Set/Save Configuration");
        set.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
                config.setID(configName.getText());
                //DIRECTORY!!!!
                config.setSeq(seq.getText());
                config.setReverseMode(reverse.isSelected());
                config.setNetworked(net.isSelected());
                config.setSearchCfg(searchProg.getText());
                config.setIndexCfg(indexDir.getText());
                config.setNumberOfTrials(Integer.parseInt(numTrial.getText()));
                config.setDdp(Integer.parseInt(datDec.getText()));
                config.setPrintLength(Transform.fromIntInput(printLength.getText()));
                config.setHydrophobic1(Transform.fromInput(hp1.getText()));
                config.setHydrophobic2(Transform.fromInput(hp2.getText()));
                config.setHydrophobic3(Transform.fromInput(hp3.getText()));
                config.setHp1Score(Transform.fromIntInput(hp1Sc.getText()));
                config.setHp2Score(Transform.fromIntInput(hp2Sc.getText()));
                config.setHp3Score(Transform.fromIntInput(hp3Sc.getText()));
                config.setPairsToAvoid(Transform.fromInput(pairsToAvoid.getText()));
                config.setPairsToFilter(Transform.fromInput(pairsToFilter.getText()));
                config.setPairToAvoidScore(Transform.fromIntInput(pairToAvoidScore.getText()));
                config.setMotif1Score(Transform.fromIntInput(mot1Score.getText()));
                config.setMotif2Score(Transform.fromIntInput(mot2Score.getText()));
                config.setMotif12Score(Transform.fromIntInput(mot12Score.getText()));
                Transform.posChargeFromInput(config,posaas.getText());
                Transform.negChargeFromInput(config,negaas.getText());
                config.setVolScale(vol.getText());
                config.writeConfig();
                rePaintPanel();
            }
            
        });
        defaults = new JButton("Set defaults");
        defaults.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
                config=new Config();
                seq.setText(config.getSeq());
                configName.setText(config.getID());
                reverse.setSelected(config.isReverseMode());
                  net.setSelected(config.isNetworked());
                  searchProg.setText(config.getSearchCfg());
                  indexDir.setText(config.getIndexCfg());
                numTrial.setText(config.getNumberOfTrials().toString());
                datDec.setText(config.getDdp().toString());
                printLength.setText(config.getPrintLength().toString());
                hp1Sc.setText(config.getHp1Score().toString());
                hp2Sc.setText(config.getHp2Score().toString());
                hp3Sc.setText(config.getHp3Score().toString());
                hp1.setText(Transform.toInput(config.getHydrophobic1()));
                hp2.setText(Transform.toInput(config.getHydrophobic2()));
                hp3.setText(Transform.toInput(config.getHydrophobic3()));
                pairsToAvoid.setText(Transform.toInput(config.getPairsToAvoid()));
                pairsToFilter.setText(Transform.toInput(config.getPairsToFilter()));
                pairToAvoidScore.setText(Transform.toIntInput(config.getPairToAvoidScore()));
                mot1Score.setText(config.getMotif1Score().toString());
                mot2Score.setText(config.getMotif2Score().toString());
                mot12Score.setText(config.getMotif12Score().toString());
                posaas.setText(Transform.posChargeToInput(config));
                negaas.setText(Transform.negChargeToInput(config));
                vol.setText(config.getVolScale());
                rePaintPanel();
            }
            
        }
        
        );
        load = new JButton("Read Configuration");
        load.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
                //Error handling is necessary.
                config.readConfig(configName.getText());
                seq.setText(config.getSeq());
                configName.setText(config.getID());
                reverse.setSelected(config.isReverseMode());
                net.setSelected(config.isNetworked());
                  searchProg.setText(config.getSearchCfg());
                  indexDir.setText(config.getIndexCfg());
                numTrial.setText(config.getNumberOfTrials().toString());
                datDec.setText(config.getDdp().toString());
                printLength.setText(config.getPrintLength().toString());
                hp1Sc.setText(config.getHp1Score().toString());
                hp2Sc.setText(config.getHp2Score().toString());
                hp3Sc.setText(config.getHp3Score().toString());
                hp1.setText(Transform.toInput(config.getHydrophobic1()));
                hp2.setText(Transform.toInput(config.getHydrophobic2()));
                hp3.setText(Transform.toInput(config.getHydrophobic3()));
                pairsToAvoid.setText(Transform.toInput(config.getPairsToAvoid()));
                pairsToFilter.setText(Transform.toInput(config.getPairsToFilter()));
                pairToAvoidScore.setText(Transform.toIntInput(config.getPairToAvoidScore()));
                mot1Score.setText(config.getMotif1Score().toString());
                mot2Score.setText(config.getMotif2Score().toString());
                mot12Score.setText(config.getMotif12Score().toString());
                posaas.setText(Transform.posChargeToInput(config));
                negaas.setText(Transform.negChargeToInput(config));
                vol.setText(config.getVolScale());
                rePaintPanel();
            }
            
        });
        wise = new JButton("CONTINUE");
        wise.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
                config.setID(configName.getText());
                //DIRECTORY!!!!
                config.setSeq(seq.getText());
                config.setReverseMode(reverse.isSelected());
                config.setNetworked(net.isSelected());
                config.setNumberOfTrials(Integer.parseInt(numTrial.getText()));
                config.setDdp(Transform.fromIntInput(datDec.getText()));
                config.setPrintLength(Transform.fromIntInput(printLength.getText()));
                config.setHydrophobic1(Transform.fromInput(hp1.getText()));
                config.setHydrophobic2(Transform.fromInput(hp2.getText()));
                config.setHydrophobic3(Transform.fromInput(hp3.getText()));
                config.setHp1Score(Transform.fromIntInput(hp1Sc.getText()));
                config.setHp2Score(Transform.fromIntInput(hp2Sc.getText()));
                config.setHp3Score(Transform.fromIntInput(hp3Sc.getText()));
                config.setPairsToAvoid(Transform.fromInput(pairsToAvoid.getText()));
                config.setPairsToFilter(Transform.fromInput(pairsToFilter.getText()));
                config.setPairToAvoidScore(Transform.fromIntInput(pairToAvoidScore.getText()));
                config.setMotif1Score(Transform.fromIntInput(mot1Score.getText()));
                config.setMotif2Score(Transform.fromIntInput(mot2Score.getText()));
                config.setMotif12Score(Transform.fromIntInput(mot12Score.getText()));
                config.setVolScale(vol.getText());
                setVisible(false);
            }
            
        });
        jpConfig = new JPanel();
        jpConfig.setLayout(new GridLayout(0,4));
        jpConfig.add(new JLabel("GENERAL OPTIONS",SwingConstants.CENTER));
        jpConfig.add(new JLabel(" "));
        jpConfig.add(new JLabel(" "));
        jpConfig.add(new JLabel(" "));
        jpConfig.add(configNameL);
        jpConfig.add(configName);
        jpConfig.add(seqL);
        jpConfig.add(seq);
        jpConfig.add(printLengthL);
        jpConfig.add(printLength);
        jpConfig.add(numTrialL);
        jpConfig.add(numTrial);
        jpConfig.add(netL);
        jpConfig.add(net);
        jpConfig.add(datDecL);
        jpConfig.add(datDec);
        if(config.isNetworked()) {
            jpConfig.add(searchProgL);
            jpConfig.add(searchProg);
            jpConfig.add(indexDirL);
            jpConfig.add(indexDir);
        }
        jpConfig.add(mot);
        jpConfig.add(mot2);
        jpConfig.add(mot3);
        jpConfig.add(mot4);
        jpConfig.add(pairsToAvoidL);
        jpConfig.add(pairsToAvoid);
        jpConfig.add(pairToAvoidScoreL);
        jpConfig.add(pairToAvoidScore);
        jpConfig.add(pairsToFilterL);
        jpConfig.add(pairsToFilter);
        jpConfig.add(new JLabel());
        jpConfig.add(new JLabel());
        jpConfig.add(smot);
        jpConfig.add(mot1Score);
        jpConfig.add(mot2Score);
        jpConfig.add(mot12Score);
        jpConfig.add(hyd);
        jpConfig.add(hyd2);
        jpConfig.add(hyd3);
        jpConfig.add(hyd4);
        jpConfig.add(hp1L);
        jpConfig.add(hp1);
        jpConfig.add(hp1ScL);
        jpConfig.add(hp1Sc);
        jpConfig.add(hp2L);
        jpConfig.add(hp2);
        jpConfig.add(hp2ScL);
        jpConfig.add(hp2Sc);
        jpConfig.add(hp3L);
        jpConfig.add(hp3);
        jpConfig.add(hp3ScL);
        jpConfig.add(hp3Sc);
        jpConfig.add(charge);
        jpConfig.add(charge2);
        jpConfig.add(charge3);
        jpConfig.add(charge4);
        jpConfig.add(pos);
        jpConfig.add(posaas);
        jpConfig.add(chScore1L);
        jpConfig.add(chScore1);
        jpConfig.add(neg);
        jpConfig.add(negaas);
        jpConfig.add(chScore2L);
        jpConfig.add(chScore2);
        jpConfig.add(volL);
        jpConfig.add(vol);
        jpConfig.add(new JPanel());
        jpConfig.add(new JPanel());
        jpConfig.add(set);
        jpConfig.add(defaults);
        jpConfig.add(load);
        jpConfig.add(wise);
        jpConfig.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        JPanel jpMain = new JPanel();
        jpMain.setLayout(new BorderLayout());
        jpMain.add(jpConfig,BorderLayout.NORTH);
        
        add(jpConfig);
        setVisible(true);
        setEnabled(true);
        waitForFrame(inpconfig, configName.getText());
    }

    private void waitForFrame(Config inpconfig, String string) {
        while(isVisible()) {
            try {
                java.lang.Thread.sleep(1);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        inpconfig.setConfig(config);
        System.err.println("Config name: "+config.getID()+" Sequence: "+config.getSeq());
        System.err.println("Config name: "+inpconfig.getID()+" Sequence: "+inpconfig.getSeq());
        //        inpconfig.readConfig(string);
        if(inpconfig.getSeq().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Original seuence is not given yet, please give one.");
            setVisible(true);
            waitForFrame(inpconfig, string);
        }
        Object[] options = {"Yes", "No"};
        int n = JOptionPane.showOptionDialog(this,
                "The configuration is going to be saved to \n\""+inpconfig.getID()+"\" for sequence: "+inpconfig.getSeq()+".\n\tContinue?",
                "PLEASE CONFIRM",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,     //do not use a custom Icon
                options,  //the titles of buttons
                options[1]); //default button title
        System.err.println("The answer is:"+n);
        if(n==0) {
            config.writeConfig();
        } else {
            setVisible(true);
            waitForFrame(inpconfig, string);
        }
    }
    
    private void rePaintPanel() {
    	remove(jpConfig);
    	jpConfig.removeAll();
    	jpConfig.setVisible(false);
        jpConfig.setLayout(new GridLayout(0,4));
        jpConfig.add(new JLabel("GENERAL OPTIONS",SwingConstants.CENTER));
        jpConfig.add(new JLabel(" "));
        jpConfig.add(new JLabel(" "));
        jpConfig.add(new JLabel(" "));
        jpConfig.add(configNameL);
        jpConfig.add(configName);
        jpConfig.add(seqL);
        jpConfig.add(seq);
        jpConfig.add(printLengthL);
        jpConfig.add(printLength);
        jpConfig.add(numTrialL);
        jpConfig.add(numTrial);
        jpConfig.add(netL);
        jpConfig.add(net);
        jpConfig.add(datDecL);
        jpConfig.add(datDec);
        if(net.isSelected()) {
            jpConfig.add(searchProgL);
            jpConfig.add(searchProg);
            jpConfig.add(indexDirL);
            jpConfig.add(indexDir);
        }
        jpConfig.add(mot);
        jpConfig.add(mot2);
        jpConfig.add(mot3);
        jpConfig.add(mot4);
        jpConfig.add(pairsToAvoidL);
        jpConfig.add(pairsToAvoid);
        jpConfig.add(pairToAvoidScoreL);
        jpConfig.add(pairToAvoidScore);
        jpConfig.add(pairsToFilterL);
        jpConfig.add(pairsToFilter);
        jpConfig.add(new JLabel());
        jpConfig.add(new JLabel());
        jpConfig.add(smot);
        jpConfig.add(mot1Score);
        jpConfig.add(mot2Score);
        jpConfig.add(mot12Score);
        jpConfig.add(hyd);
        jpConfig.add(hyd2);
        jpConfig.add(hyd3);
        jpConfig.add(hyd4);
        jpConfig.add(hp1L);
        jpConfig.add(hp1);
        jpConfig.add(hp1ScL);
        jpConfig.add(hp1Sc);
        jpConfig.add(hp2L);
        jpConfig.add(hp2);
        jpConfig.add(hp2ScL);
        jpConfig.add(hp2Sc);
        jpConfig.add(hp3L);
        jpConfig.add(hp3);
        jpConfig.add(hp3ScL);
        jpConfig.add(hp3Sc);
        jpConfig.add(charge);
        jpConfig.add(charge2);
        jpConfig.add(charge3);
        jpConfig.add(charge4);
        jpConfig.add(pos);
        jpConfig.add(posaas);
        jpConfig.add(chScore1L);
        jpConfig.add(chScore1);
        jpConfig.add(neg);
        jpConfig.add(negaas);
        jpConfig.add(chScore2L);
        jpConfig.add(chScore2);
        jpConfig.add(volL);
        jpConfig.add(vol);
        jpConfig.add(new JPanel());
        jpConfig.add(new JPanel());
        jpConfig.add(set);
        jpConfig.add(defaults);
        jpConfig.add(load);
        jpConfig.add(wise);
        jpConfig.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        JPanel jpMain = new JPanel();
        jpMain.setLayout(new BorderLayout());
        jpMain.add(jpConfig,BorderLayout.NORTH);
        jpConfig.setVisible(true);
        add(jpConfig);
        setVisible(true);
   }


}