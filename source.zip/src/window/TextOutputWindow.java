package window;

import java.io.FileNotFoundException;
import java.io.PrintStream;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JViewport;
import javax.swing.WindowConstants;
import main.Shuffling;

public class TextOutputWindow {
    
    JFrame f = null;
    JViewport p = null;
    JTextArea t = null;
    JScrollPane sp = null;
    PrintStream output;
    private boolean clm = false;
    
    public TextOutputWindow() throws FileNotFoundException {
        this.output = System.out;
//            super();
                if(Shuffling.clm) {
                    clm=true;
                }
        // TODO Auto-generated constructor stub
    }

    /**
     * Print an empty line
     */
    public void println() {
            if(clm) {
                output.println();
            } else {
        println("\n");
            }
    }
    
    /**
     *
     * @param s
     */
    public void println(String s) {
            if(clm) {
                output.println(s);
            } else {
        if (f==null) {
            f=new JFrame("Output");
        }
        if(sp==null) {
            sp = new JScrollPane();
            p = new JViewport();
            sp.setViewport(p);
            f.add(sp);
            f.setSize(640,480);
        }
        if(t==null) {
            t=new JTextArea(s+"\n");
            t.setEditable(false);
            p.add(t);
            f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
            JFrame.setDefaultLookAndFeelDecorated(true);
            f.setVisible(true);
        } else {
            t.append(s+"\n");
            t.setCaretPosition(t.getDocument().getLength());
        }
        sp.setVisible(true);
        p.setVisible(true);
        t.setAutoscrolls(true);
            }
    }
    
    /**
     *
     * @param s
     */
    public void print(String s) {
            if(clm) {
                output.print(s);
            } else {
        println(s);
            }
    }
    
}