package window.documentation;

import java.awt.Dimension;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JViewport;
import javax.swing.WindowConstants;

public class Doksi extends JFrame {
    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    public Doksi(String header) {
        super(header);
        setSize(970,600);
        setMinimumSize(new Dimension(970,370));
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
    }

    public void showDoc(String text) {
        JScrollPane jpdokp = new JScrollPane();
        JViewport p = new JViewport();
        jpdokp.setViewport(p);
        JTextArea jtdokA = new JTextArea();
        jtdokA.setFont(jtdokA.getFont().deriveFont(12f));
        jtdokA.setText(text);
        jtdokA.setEditable(false);
        p.add(jtdokA);
        jpdokp.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(jpdokp);
        setVisible(true);
    }

}