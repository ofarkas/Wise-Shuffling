package xml;
/**
 * This class represents a very simple XML reader/writer.
 * The content of the file is represented in the variable "content" as HashMap.
 * The file name should be specified in the Constructor.
 * The method writeOut writes the content to the file in XML form and closes it.
 * The method readIn reads the content from the file. 
 */

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.HashMap;

import javax.sql.rowset.spi.XmlWriter;

public class MyXMLHashMap {
    
    File xmlFile = null;
    XmlWriter writer = null;
    XMLDecoder decode = null;
//    new XMLDecoder(new BufferedInputStream(new FileInputStream(xmlFile)));
    XMLEncoder encoder = new XMLEncoder(System.out);
    HashMap<String, String> content = new HashMap<>();
    

    public MyXMLHashMap(File f) {
        if (f==null) {
            throw new RuntimeException("No XML file given.");
        } else {
            xmlFile = f;
        }
    }
    
    public void writeOut() {
        try {
            encoder=new XMLEncoder(new FileOutputStream(xmlFile));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        encoder.writeObject(content);
        encoder.close();
    }
    
    @SuppressWarnings("unchecked")
    public void readIn() {
        if(decode==null) {
            try {
                decode=new XMLDecoder(new FileInputStream(xmlFile));
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        content=(HashMap<String, String>) decode.readObject();
    }

    /**
     * @return the content
     */
    public HashMap<String, String> getContent() {
        return content;
    }

    /**
     * @param content the content to set
     */
    public void setContent(HashMap<String, String> content) {
        this.content = content;
    }
    
}