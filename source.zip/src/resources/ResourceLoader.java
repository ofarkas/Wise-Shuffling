package resources;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;

import javax.imageio.ImageIO;
public class ResourceLoader {
    static ResourceLoader rl = new ResourceLoader();
     
    public static BufferedImage loadImage(String imageName)
    {
    	BufferedImage img = null;
    	try {
    		URL url = rl.getClass().getResource("images/"+imageName);
    		System.err.println("Read csikook from:"+url.toString());
			img = ImageIO.read(rl.getClass().getResource("images/"+imageName));
		} catch (IOException e) {
			e.printStackTrace();
		}
    	return img;
    }
    public static String loadText(String textFileName) {
    	String text="";
    	System.err.println("Read text from "+textFileName);
		InputStreamReader is = new InputStreamReader(rl.getClass().getResourceAsStream("text/"+textFileName));
		BufferedReader buff = new BufferedReader(is);
		String line="";
		try {
			line = buff.readLine();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		while (line!=null) {
		try {
			text += line+"\n";
			line = buff.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		}
		}
		System.out.println(text);
		return text;
    	
    }

    }