/**
 * 
 */
package examiner;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * @author farkas
 *
 */
public class SeqScore {
    private String seq = "";
    private ArrayList<Integer> scores = new ArrayList<Integer>(6);
    public static final int MOTIF = 0;
    public static final int HIDROPHOBIC = 1;
    public static final int PAIRS = 2;
    public static final int VOLUME = 3;
    public static final int CHARGE = 4;
    public static final int DATDET = 5;
    private int sum=-1;
    
    public SeqScore() {
        scores.add(0);
        scores.add(0);
        scores.add(0);
        scores.add(0);
        scores.add(0);
        scores.add(0);
    }
    /**
     * @return the sum
     */
    public int getSum() {
        if(sum>=0) return sum;
        int s=0;
        for (Iterator<Integer> iterator = scores.iterator(); iterator.hasNext();) {
            s += iterator.next();
        }
        sum=s;
        return sum;
    }
    /**
     * reset the sum if any score changes
     */
    public void resetSum() {
        sum=-1;
    }
    /**
     * @return the seq
     */
    public String getSeq() {
        return seq;
    }
    /**
     * @param seq the seq to set
     */
    public void setSeq(String seq) {
        this.seq = seq;
    }
    /**
     * @return the scores
     */
    public ArrayList<Integer> getScores() {
        return scores;
    }
    /**
     * @param scores the scores to set
     */
    public void setScores(ArrayList<Integer> scores) {
        this.scores = scores;
    }
    @Override
    public boolean equals(Object obj) {
        SeqScore other = (SeqScore)obj;
        if(!other.seq.equals(seq)) return false;
        return true;
    }
    
}