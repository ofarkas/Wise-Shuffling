/**
 * 
 */
package examiner;

/**
 * @author farkas
 *
 */
public class Sort {
    
    Sortable toSort;
    
    
    
    public Sort(Sortable toSort) {
        super();
        this.toSort = toSort;
        quickSort(toSort, 0, toSort.getLength()-1);
    }
    
    public Sortable getResult() {
        return toSort;
    }

    private void quickSort(Sortable arr, int begin, int end) {
        if (begin < end) {
            int partitionIndex = partition(arr, begin, end);

            quickSort(arr, begin, partitionIndex-1);
            quickSort(arr, partitionIndex+1, end);
        }
    }

    private int partition(Sortable arr, int begin, int end) {
        int pivot = end;
        int i = (begin-1);

        for (int j = begin; j < end; j++) {
            if (arr.test(j,pivot)) {
                i++;
                
                arr.swap(i, j);
//                int swapTemp = arr[i];
//                arr[i] = arr[j];
//                arr[j] = swapTemp;
            }
        }

        arr.swap(i+1, end);
//        int swapTemp = arr[i+1];
//        arr[i+1] = arr[end];
//        arr[end] = swapTemp;

        return i+1;
    }
    
}