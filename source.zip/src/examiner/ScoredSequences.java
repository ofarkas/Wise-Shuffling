/**
 * 
 */
package examiner;

import java.util.ArrayList;

/**
 * @author farkas
 *
 */
public class ScoredSequences extends ArrayList<SeqScore> implements Sortable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private boolean ascending=true;

    public ScoredSequences(boolean ascending) {
        this.ascending=ascending;
    };
    
    @Override
    public boolean test(int i, int j) {
        boolean res=false;
        if(ascending) {
            res=this.get(i).getSum()<=this.get(j).getSum();
        } else {
            res=this.get(i).getSum()>=this.get(j).getSum();
            
        }
        return res;
    }

    @Override
    public void swap(int i, int j) {
        SeqScore tmp=this.get(i);
        this.set(i, this.get(j));
        this.set(j,tmp);
    }

    public int getLength() {
        return this.size();
    }

}