/**
 * 
 */
package examiner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.StringTokenizer;
import config.Config;

/**
 * @author farkas
 *
 */
public class CheckSequence {
    
    HashMap<String, Integer> aavolumes = null; 
    HashMap<String, Integer> aacharges = null; 
    
    SeqScore sequence = null;
    int[] refVolumes = null;
    int[] refCharges = null;
    Config config;
    boolean pairsOK = true;
    Set <String> pairsToAvoid = null;
    Set <String> pairsToFilter = null;
    Set <String> hydPhob1 = null;
    Set <String> hydPhob2 = null;
    Set <String> hydPhob3 = null;
    int chScore1=20;
    int chScore2=50;
    public boolean doCharge=false;

    public CheckSequence(SeqScore seq, Config cfg) {
        this.config = cfg;
        this.sequence = seq;
        int l=config.getPairsToAvoid().trim().length();
        pairsToAvoid = new HashSet<String>(l);
        //Prepare the set of AA pairs to avoid
        StringTokenizer st = new StringTokenizer(cfg.getPairsToAvoid());
        while(st.hasMoreTokens()) {
            pairsToAvoid.add(st.nextToken());
        }
        pairsToFilter = new HashSet<String>(l);
        //Prepare the set of AA pairs to avoid
        st = new StringTokenizer(cfg.getPairsToFilter());
        while(st.hasMoreTokens()) {
            pairsToFilter.add(st.nextToken());
        }
        hydPhob1=new HashSet<String>();
        hydPhob2=new HashSet<String>();
        hydPhob3=new HashSet<String>();
        //Prepare the set of hydrophobic AAs
        st = new StringTokenizer(cfg.getHydrophobic1());
        while(st.hasMoreTokens()) {
            hydPhob1.add(st.nextToken());
        }
        st = new StringTokenizer(cfg.getHydrophobic2());
        while(st.hasMoreTokens()) {
            hydPhob2.add(st.nextToken());
        }
        st = new StringTokenizer(cfg.getHydrophobic3());
        while(st.hasMoreTokens()) {
            hydPhob3.add(st.nextToken());
        }
        if(aavolumes==null) {
            aavolumes = new HashMap<String, Integer>();
            String[] aa = config.getAminoacids().split("\n");
            String[] av = config.getVolumes().split("\n");
            for (int i = 0; i < aa.length; i++) {
                aavolumes.put(aa[i], Integer.parseInt(av[i]));
            }
        }
        if(aacharges==null) {
            aacharges = new HashMap<String, Integer>();
            String[] aa = config.getAminoacids().split("\n");
            String[] ac = config.getCharges().split("\n");
            for (int i = 0; i < aa.length; i++) {
                aacharges.put(aa[i], Integer.parseInt(ac[i]));
            }
        }
        chScore1=cfg.getChScore1();
        chScore2=cfg.getChScore2();
        String refseq=sequence.getSeq();
        refVolumes=new int[refseq.length()];
        refCharges=new int[refseq.length()];
        int np=0;
        int nn=0;
        for (int i=0; i<refseq.length(); i++) {
            String aa=refseq.substring(i,i+1);
            Integer av=aavolumes.get(aa);
            Integer ac=aacharges.get(aa);
            int aVol=0;
            int aCh=0;
            if(av!=null) {
                aVol=av.intValue();
            }
            if(ac!=null) {
                aCh=ac.intValue();
            }
            if(aCh==1) np++;
            if(aCh==-1) nn++;
            doCharge=((np>1)||(nn>1));
            refVolumes[i]=aVol;
            refCharges[i]=aCh;
        }
    }
    
    public void addNetPenalty(SeqScore s) {
        s.getScores().set(SeqScore.DATDET,config.getDdp());
        s.resetSum();
    }
    
    public void check(SeqScore s) {
        pairScore(s);
        hydroCheck(s);
        motifScore(s);
        volCheck(s);
        chargeCheck(s);
        }
    
    public boolean arePairsOK(SeqScore s) {
        final int pairScore=config.getPairToAvoidScore();
        String seq="";
        if(s.getSeq().indexOf("^")==0) {
            seq=s.getSeq();
        } else {
            seq="^"+s.getSeq()+"$";
        }
        int ps=0;
        for (Iterator<String> iterator = pairsToAvoid.iterator(); iterator.hasNext();) {
            String string = (String) iterator.next();
            ps+=CheckCharPositions.matchCount(seq,string);
        }
        pairsOK= (ps==0);
        s.getScores().set(SeqScore.PAIRS, ps*pairScore);
        return pairsOK;
    }
    
    public boolean isFiltered(SeqScore s) {
        String seq="";
        if(s.getSeq().indexOf("^")==0) {
            seq=s.getSeq();
        } else {
            seq="^"+s.getSeq()+"$";
        }
        int ps=0;
        for (Iterator<String> iterator = pairsToFilter.iterator(); iterator.hasNext();) {
            String string = (String) iterator.next();
            ps+=CheckCharPositions.matchCount(s.getSeq(),string);
            if(seq.indexOf(string)>=0) ps++; 
            
        }
        pairsOK= (ps!=0);
        return pairsOK;
    }

    public void motifScore(SeqScore s) {
        String seq=s.getSeq();
        ArrayList<String> seqPairs = new ArrayList<String>();
        Character[] pair = new Character[2];
        for (int i = 0; i < seq.length()-1; i++) {
            pair[0] = seq.charAt(i);
            pair[1] = seq.charAt(i+1);
            seqPairs.add(pair[0].toString()+pair[1].toString());
        }
        ArrayList<String> seqNeighbours = new ArrayList<String>();
        for (int i = 0; i < seq.length()-2; i++) {
            pair[0] = seq.charAt(i);
            pair[1] = seq.charAt(i+2);
            seqNeighbours.add(pair[0].toString()+pair[1].toString());
        }
        int score = 0;
        CheckCharPositions ccp=new CheckCharPositions(sequence.getSeq());
        //Check for AB and "AB -> A.B" motif
        for (Iterator<String> iterator = seqPairs.iterator(); iterator.hasNext();) {
            String motif = (String) iterator.next();
            score+=ccp.motifCount(motif)*config.getMotif1Score();
            motif = motif.charAt(0) + "." + motif.charAt(1);
            score+=ccp.motifCount(motif)*config.getMotif12Score();
        }
        //Check for A.B and "A.B -> AB" motif
        for (Iterator<String> iterator = seqNeighbours.iterator(); iterator.hasNext();) {
            String motif = (String) iterator.next();
            score+=ccp.motifCount(motif)*config.getMotif12Score();
            motif = motif.charAt(0) + "." + motif.charAt(1);
            score+=ccp.motifCount(motif)*config.getMotif2Score();
        }
        ArrayList<Integer> scores = s.getScores();
        scores.set(SeqScore.MOTIF,score);
        s.setScores(scores);
    }
    
    public void pairScore(SeqScore s) {
        arePairsOK(s);
    }
    
    public void hydroCheck(SeqScore s) {
        
        String seq=s.getSeq();
        int ahs=0;
        int score=0;
        int sc=0;
        for (int i = 0; i < seq.length(); i++) {
            Character aaCh=seq.charAt(i);
            String aa=aaCh.toString();
            boolean hp1=hydPhob1.contains(aa);
            boolean hp2=hydPhob2.contains(aa);
            boolean hp3=hydPhob3.contains(aa);
            if(hp1) sc=config.getHp1Score();
            if(hp2) sc=config.getHp2Score();
            if(hp3) sc=config.getHp3Score();
            if(sc==0) {
                if(ahs>0) score+=ahs;
                ahs=0;
            } else if(ahs==0) {
                ahs=-sc;
                sc=0;
            } else if (ahs<0) {
                ahs*=-sc;
                sc=0;
            } else {
                ahs*=sc;
                sc=0;
            }
        }
        if(ahs>0) score+=ahs;
        s.getScores().set(SeqScore.HIDROPHOBIC, score);
    }

    public void volCheck(SeqScore s) {
        String seq = s.getSeq();
        int score=0;
        if(refVolumes.length!=seq.length()) {
            System.err.println("Sequence length mismatch...");
        }
        try {
            for (int i = 0; i < refVolumes.length; i++) {
                int vol=aavolumes.get(seq.substring(i,i+1));
                score+=Math.abs(vol-refVolumes[i]);
            }
        } catch (Exception e) {
            System.err.println("Amino acid with no defined volume used in the sequence.");
            score=0;
        }
        s.getScores().set(SeqScore.VOLUME, score);
    }

    public void chargeCheck(SeqScore s) {
        if(!doCharge) return;
        String seq = s.getSeq();
        int score=0;
        if(refCharges.length!=seq.length()) {
            System.err.println("Sequence length mismatch...");
        }
        try {
        for (int i = 0; i < refCharges.length; i++) {
            int ch=aacharges.get(seq.substring(i,i+1));
            int rch = refCharges[i];
            if(ch!=rch) {
                if(ch*rch==0) {
                    score+=chScore1;
                } else {
                    score+=chScore2;
                }
            }
        }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        s.getScores().set(SeqScore.CHARGE, score);
    }

    /**
     * The number of elements in set1 should be lower or equal than
     * the number of elements in set2.
     *  
     * @param set1 checks each of its elements to be in set2
     * @param set2 its 'contains' method will be used
     * @return the number of elements in the intersection
     */
    @SuppressWarnings("rawtypes")
    public int interSectSize(Set set1, Set set2) {;
        int sum = 0;
        for (Iterator iterator = set1.iterator(); iterator.hasNext();) {
            String p = (String) iterator.next();
            if(set2.contains(p)) {
                System.err.print(p);
                sum++;
            }
        }
        return sum;
    }
    
}