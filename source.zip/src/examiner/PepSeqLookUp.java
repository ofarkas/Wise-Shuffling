/**
 * 
 */
package examiner;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import config.Config;


/**
 * This class searches the 
 * @author farkas
 *
 */



public class PepSeqLookUp {
    
private String seq="";

/**
 * @return the peptide sequence
 */
public String getSeq() {
    return seq;
}

/**
 * @param seq the peptide sequence to set 
 */
public void setSeq(String seq) {
    this.seq = seq;
}

public PepSeqLookUp(String seq) {
    super();
    this.seq = seq;
}

public int lookup(Config config) {
//    String pepdblookup="/home/farkas/Documents/UNIPROT/"+"PeptideMatchCMD_1.1.jar";
    String pepdblookup=config.getSearchCfg();
//    String indexdir="/home/farkas/Documents/UNIPROT/fullidx";
    String indexdir=config.getIndexCfg();
    String outputFile="WSdblookout.scr";
    ArrayList<String> argList = new ArrayList<String>();
    argList.add("java");
    argList.add("-jar");
    argList.add(pepdblookup);
    argList.add("-a");
    argList.add("query");
    argList.add("-i");
    argList.add(indexdir);
    argList.add("-o");
    argList.add(outputFile);
    argList.add("-q");
    argList.add(getSeq());
    ProcessBuilder pb=new ProcessBuilder(argList);
    System.out.println(argList.toString());
    int nl=0;
    try {
        BufferedReader br=new BufferedReader(new InputStreamReader(pb.start().getInputStream()));
        String line = " ";
        while (line!=null) {
            line=br.readLine();
            System.out.println(line);
            if (line==null) {
                continue;
            } else {
            	nl++;
            }
            if(line.contains("has no match")) {
                System.out.println(" 0");
                return 0;
            }
        }
    } catch (IOException e) {
        e.printStackTrace();
        System.out.println(" -1");
        return -1;
    }
    if(nl==0) {
        System.out.println("Empty output -1");
        return -1;
    }
    System.out.println(" 1");
    return 1;
    
}


}