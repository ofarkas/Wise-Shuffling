/**
 * 
 */
package examiner;

/**
 * @author farkas
 *
 */
public interface Sortable{
    
    public boolean test(int i, int j);
    
    public void swap(int i, int j);
    
    public Object get(int i);
    
    public int getLength();

}