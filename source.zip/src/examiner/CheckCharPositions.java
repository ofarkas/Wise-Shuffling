/**
 * 
 */
package examiner;

/**
 * @author farkas
 *
 */
public class CheckCharPositions {
    
    String orig = null;     //Original String
    String revOrig = null;    //Reverse original Strin
    public CheckCharPositions(String orig) {
        super();
        this.orig = orig;
        this.revOrig=reverse(orig);
    }

    private String reverse( String o) {
        String rev="";
        for (int i = 0; i < o.length(); i++) {
            rev=o.charAt(i)+rev;
        }
        return rev;
    }
    
    public int firstCommonPos(String s) {
        System.err.print(s+":");
        if(s.length()!=orig.length()) {
            return -1;
        }
        for (int i = 0; i < s.length(); i++) {
            if(s.charAt(i)==orig.charAt(i)) {
                System.err.println(" "+s.charAt(i)+"="+orig.charAt(i));
                return i;
            }
            if(s.charAt(i)==revOrig.charAt(i)) {
                System.err.println(" "+s.charAt(i)+"="+revOrig.charAt(i));
                return i;
            }
        }
        System.err.println();
        return -1;
    }
    
    public boolean hasCommonPos(String s) {
        if(firstCommonPos(s)!=-1) return true;
        return false;
    }
    
    public int scoreCommonPatterns( String seq) {
        for (int i = 0; i < seq.length()-1; i++) {
            
        }
        
        return 0;
        
    }
    
    
    
    //Find
    public static int matchCount(String o, String motif) {
        int l=motif.length();
        if(l>o.length()) return 0;
        int pos=0;
        int count=0;
        while ((pos+l)<=o.length()) {
            String om=o.substring(pos, pos+l);
            if(om.length()!=l) throw new NullPointerException();
            if(om.matches(motif)) count++;
            pos++;
        }
        return count;
    }
    
    public int motifCount(String motif) {
        return matchCount(orig,motif)+matchCount(revOrig,motif);
    }
    
    public int arbitraryMotifCount(String motif) {
        return matchCount(orig,motif);
    }
}