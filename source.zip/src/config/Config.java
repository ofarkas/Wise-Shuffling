package config;

import java.io.File;
import java.io.Serializable;
import java.util.HashMap;

import xml.MyXMLHashMap;

public class Config implements Serializable {

    /**
     * 
     */
//    public static ReadConfig rc=null;
    private static final long serialVersionUID = 1L;
    
    private String resList = null;
    /**
     * @return the reverseMode
     */
    public boolean isReverseMode() {
        return reverseMode;
    }

    public boolean distribution = false;

    /**
     * @param reverseMode the reverseMode to set
     */
    public void setReverseMode(boolean reverseMode) {
        this.reverseMode = reverseMode;
    }
    private HashMap<String, String> configMap = new HashMap<>();

    boolean networked = false;
    /**
     * @return the networked
     */
    public boolean isNetworked() {
        return networked;
    }



    /**
     * @param networked the networked to set
     */
    public void setNetworked(boolean networked) {
        this.networked = networked;
    }
    private String searchCfg="PeptideMatchCMD_1.1.jar";
    private String indexCfg="~/Documents/UNIPROT/fullidx";
    boolean reverseMode = false;
    Integer numberOfTrials = 100000;
    Integer printLength = 10;
    String ID="shuffling.cfg";
    /**
     * @return the seq
     */
    public String getSeq() {
        return seq;
    }



    /**
     * @param seq the seq to set
     */
    public void setSeq(String seq) {
        this.seq = seq;
    }

    String seq="SEQVENTIA";
    boolean keepOrigSequence=false;
    boolean substitutionRequired=false;
    boolean similarityIsDesired=true;
    boolean randomChanges=true;
    String pairsToAvoid="DG\n"
            + "GD\n"
            + "GN\n"
            + "NG\n"
            + "FF\n"
            + "YY\n"
            + "^E\n"
            + "^C\n"
            + "C$";
    String pairsToFilter=" ";
    public String getPairsToFilter() {
		return pairsToFilter;
	}



	public void setPairsToFilter(String pairsToFilter) {
		this.pairsToFilter = pairsToFilter;
	}

	String hydrophobic1 = "F\n"+
            "Y";
    String hydrophobic2 = "P\n"+
            "L\n"+
            "I\n"+
            "V";
    String hydrophobic3 = "G\n"+
            "A";
    Integer motif1Score  = 100;
    Integer motif2Score  = 20;
    Integer motif12Score = 10;
    Integer hp1Score = 10;
    Integer hp2Score = 5;
    Integer chScore1 = 20;
    /**
     * @return the chScore1
     */
    public Integer getChScore1() {
        return chScore1;
    }



    /**
     * @param chScore1 the chScore1 to set
     */
    public void setChScore1(Integer chScore1) {
        this.chScore1 = chScore1;
    }



    /**
     * @return the chScore2
     */
    public Integer getChScore2() {
        return chScore2;
    }



    /**                        int median=0;
                        int nn=res.size();

     * @param chScore2 the chScore2 to set
     */
    public void setChScore2(Integer chScore2) {
        this.chScore2 = chScore2;
    }

    Integer chScore2 = 50;
    Integer pairToAvoidScore = 100;
    String aminoacids = "A\n"
            + "R\n"
            + "N\n"
            + "D\n"
            + "C\n"
            + "Q\n"
            + "E\n"
            + "G\n"
            + "H\n"
            + "I\n"
            + "L\n"
            + "K\n"
            + "M\n"
            + "F\n"
            + "P\n"
            + "S\n"
            + "T\n"
            + "W\n"
            + "Y\n"
            + "V\n";
    /**
     * @return the aminoacids
     */
    public String getAminoacids() {
        return aminoacids;
    }



    /**
     * @param aminoacids the aminoacids to set
     */
    public void setAminoacids(String aminoacids) {
        this.aminoacids = aminoacids;
    }



    /**
     * @return the volumes
     */
    public String getVolumes() {
        return volumes;
    }



    /**
     * @param volumes the volumes to set
     */
    public void setVolumes(String volumes) {
        this.volumes = volumes;
    }



    /**
     * @return the volScale
     */
    public String getVolScale() {
        return volScale;
    }



    /**
     * @param volScale the volScale to set
     */
    public void setVolScale(String volScale) {
        this.volScale = volScale;
    }

    String volumes= "25\n"
            + "149\n"
            + "70\n"
            + "62\n"
            + "53\n"
            + "97\n"
            + "87\n"
            + "0\n"
            + "102\n"
            + "94\n"
            + "96\n"
            + "121\n"
            + "103\n"
            + "127\n"
            + "59\n"
            + "38\n"
            + "61\n"
            + "162\n"
            + "138\n"
            + "72\n";
    String volScale = "1.0";

    String charges = "0\n"
            + "1\n"
            + "0\n"
            + "-1\n"
            + "0\n"
            + "0\n"
            + "-1\n"
            + "0\n"
            + "1\n"
            + "0\n"
            + "0\n"
            + "1\n"
            + "0\n"
            + "0\n"
            + "0\n"
            + "0\n"
            + "0\n"
            + "0\n"
            + "0\n"
            + "0\n";

    
    /**
     * @return the pairToAvoidScore
     */
    public Integer getPairToAvoidScore() {
        return pairToAvoidScore;
    }

    Integer ddp = 500; // Database detection penalty

    public Integer getDdp() {
        return ddp;
    }



    public void setDdp(Integer ddp) {
        this.ddp = ddp;
    }



    /**
     * @param pairToAvoidScore the pairToAvoidScore to set
     */
    public void setPairToAvoidScore(Integer pairToAvoidScore) {
        this.pairToAvoidScore = pairToAvoidScore;
    }



    /**
     * @return the motif1Score
     */
    public Integer getMotif1Score() {
        return motif1Score;
    }



    /**
     * @return the numberOfTrials
     */
    public Integer getNumberOfTrials() {
        return numberOfTrials;
    }



    /**
     * @param numberOfTrials the numberOfTrials to set
     */
    public void setNumberOfTrials(Integer numberOfTrials) {
        this.numberOfTrials = numberOfTrials;
    }



    /**
     * @return the printLength
     */
    public Integer getPrintLength() {
        return printLength;
    }



    /**
     * @param printLength the printLength to set
     */
    public void setPrintLength(Integer printLength) {
        this.printLength = printLength;
    }



    /**
     * @param motif1Score the motif1Score to set
     */
    public void setMotif1Score(Integer motif1Score) {
        this.motif1Score = motif1Score;
    }



    /**
     * @return the motif2Score
     */
    public Integer getMotif2Score() {
        return motif2Score;
    }



    /**
     * @param motif2Score the motif2Score to set
     */
    public void setMotif2Score(Integer motif2Score) {
        this.motif2Score = motif2Score;
    }



    /**
     * @return the motif12Score
     */
    public Integer getMotif12Score() {
        return motif12Score;
    }



    /**
     * @param motif12Score the motif12Score to set
     */
    public void setMotif12Score(Integer motif12Score) {
        this.motif12Score = motif12Score;
    }



    /**
     * @return the hp1Score
     */
    public Integer getHp1Score() {
        return hp1Score;
    }



    /**
     * @param hp1Score the hp1Score to set
     */
    public void setHp1Score(Integer hp1Score) {
        this.hp1Score = hp1Score;
    }



    /**
     * @return the charges
     */
    public String getCharges() {
        return charges;
    }



    /**
     * @param charges the charges to set
     */
    public void setCharges(String charges) {
        this.charges = charges;
    }



    /**
     * @return the hp2Score
     */
    public Integer getHp2Score() {
        return hp2Score;
    }



    /**
     * @param hp2Score the hp2Score to set
     */
    public void setHp2Score(Integer hp2Score) {
        this.hp2Score = hp2Score;
    }



    /**
     * @return the hp3Score
     */
    public Integer getHp3Score() {
        return hp3Score;
    }



    /**
     * @param hp3Score the hp3Score to set
     */
    public void setHp3Score(Integer hp3Score) {
        this.hp3Score = hp3Score;
    }

    Integer hp3Score = 2;
    
    
    
    
    public Config() {
        
    }



    public boolean isKeepOrigSequence() {
        return keepOrigSequence;
    }



    public void setKeepOrigSequence(boolean keepOrigSequence) {
        this.keepOrigSequence = keepOrigSequence;
    }



    public boolean isSubstitutionRequired() {
        return substitutionRequired;
    }



    public void setSubstitutionRequired(boolean substitutionRequired) {
        this.substitutionRequired = substitutionRequired;
    }



    public boolean isSimilarityIsDesired() {
        return similarityIsDesired;
    }



    public void setSimilarityIsDesired(boolean similarityIsDesired) {
        this.similarityIsDesired = similarityIsDesired;
    }



    public boolean isRandomChanges() {
        return randomChanges;
    }



    public void setRandomChanges(boolean randomChanges) {
        this.randomChanges = randomChanges;
    }



    public String getPairsToAvoid() {
        return pairsToAvoid;
    }



    public void setPairsToAvoid(String pairsToAvoid) {
        this.pairsToAvoid = pairsToAvoid;
    }
    
    @Override
    public String toString() {
        String cfgOut="Scramble configuration:\n";
        cfgOut += "Use existing local UNIPROT database for sequence lookup: "+this.isNetworked()+"\n";
        cfgOut += "Development option reverseMode is "+this.isReverseMode()+"\n";
        cfgOut += "Max number of random permutations:"+this.numberOfTrials+"\n";
        cfgOut += "Number of results to print out:"+this.printLength+"\n";
        cfgOut += "Database detection penalty:"+this.getDdp().toString()+"\n";
        cfgOut += "Avoid the following motifs:\n"+Transform.toInput(this.pairsToAvoid)+"\n";
        if(!Transform.toInput(this.pairsToFilter).isEmpty()) {
        	cfgOut += "Filter out the following motifs:\n"+Transform.toInput(this.pairsToFilter)+"\n";
        } else {
        	cfgOut += "Motif filtering is not active.\n";
        }
        cfgOut += "Most hydrophobic amino acids:\n"+Transform.toInput(this.hydrophobic1)+"\n";
        cfgOut += "Moderately hydrophobic amino acids:\n"+Transform.toInput(this.hydrophobic2)+"\n";
        cfgOut += "Least hydrophobic amino acids:\n"+Transform.toInput(this.hydrophobic3)+"\n";
        cfgOut += "Positively charged amino acids:"+Transform.posChargeToInput(this)+"\n";
        cfgOut += "Negatively charged amino acids:"+Transform.negChargeToInput(this)+"\n";
        cfgOut += "\"??\" motif score: "+this.motif1Score+"\n";
        cfgOut += "\"?.?\" motif score: "+this.motif2Score+"\n";
        cfgOut += "\"?? -> ?.?\" motif score: "+this.motif12Score+"\n";
        cfgOut += "Hydrophobic scores are: "+this.hp1Score+", "+this.hp2Score+" and "+this.hp3Score+"\n";
        cfgOut += "Motifs to avoid score: "+this.pairToAvoidScore+"\n";
        cfgOut += "Charged/uncharged match penalty: "+this.chScore1+"\n";
        cfgOut += "Opposite charge match penalty: "+this.chScore2+"\n";
        String[] aa = aminoacids.split("\n");
        String[] av = volumes.split("\n");
        cfgOut += "Amino acid sidechain volumes:\n";
        for (int i = 0; i < aa.length; i++) {
            cfgOut += " "+aa[i]+" "+av[i]+"\n";
        }
        cfgOut += "Scaling factor for comparing volume motifs:"+this.volScale+"\n";
        return cfgOut;
    }



    public String getHydrophobic1() {
        return hydrophobic1;
    }

    public String getHydrophobic2() {
        return hydrophobic2;
    }

    public String getHydrophobic3() {
        return hydrophobic3;
    }

    public void setHydrophobic1(String hydrophobic) {
        this.hydrophobic1 = hydrophobic;
    }

    public void setHydrophobic2(String hydrophobic) {
        this.hydrophobic2 = hydrophobic;
    }

    public void setHydrophobic3(String hydrophobic) {
        this.hydrophobic3 = hydrophobic;
    }



//    @Override
//    public void destroy() {
//        // TODO Auto-generated method stub



//    @Override
//    public ServletConfig getServletConfig() {
//        // TODO Auto-generated method stub
    
//    @SuppressWarnings("static-access")
//    public static ReadConfig getRC(PrintStream out, String cfgName) {
//        ReadConfig rc = new ReadConfig();



    /**
     * @return the iD
     */
    public String getID() {
        return ID;
    }



    /**
     * @param iD the iD to set
     */
    public void setID(String iD) {
        ID = iD;
    }



    /**
     * @return the configMap
     */
    public HashMap<String, String> getConfigMap() {
//        String val=Boolean.toString(isReverseMode());
        configMap.put("networked", Boolean.toString(isNetworked()));
        configMap.put("dbLookUpPrg", getSearchCfg());
        configMap.put("indexDir", getIndexCfg());
        configMap.put("databaseDetectionP", getDdp().toString());
        configMap.put("reverseMode", Boolean.toString(isReverseMode()));
        configMap.put("aminoacids", getAminoacids());
        configMap.put("charges", getCharges());
        configMap.put("hydrophobic1", getHydrophobic1());
        configMap.put("hydrophobic2", getHydrophobic2());
        configMap.put("hydrophobic3", getHydrophobic3());
        configMap.put("pairsToAvoid", getPairsToAvoid());
        configMap.put("pairsToFilter", getPairsToFilter());
        configMap.put("seq", getSeq());
        configMap.put("volScale", getVolScale());
        configMap.put("volumes", getVolumes());
        configMap.put("ID", getID());
        configMap.put("Hp1Score", Integer.toString(getHp1Score()));
        configMap.put("Hp2Score", Integer.toString(getHp2Score()));
        configMap.put("Hp3Score", Integer.toString(getHp3Score()));
        configMap.put("motif1Score", Integer.toString(getMotif1Score()));
        configMap.put("motif2Score", Integer.toString(getMotif2Score()));
        configMap.put("motif12Score", Integer.toString(getMotif12Score()));
        configMap.put("pairToAvoidScore", Integer.toString(getPairToAvoidScore()));
        configMap.put("ch1Score", Integer.toString(getChScore1()));
        configMap.put("ch2Score", Integer.toString(getChScore2()));
        configMap.put("volScale", getVolScale());
        configMap.put("numTrial", getNumberOfTrials().toString());
        configMap.put("printLength", getPrintLength().toString());
        configMap.put("results",resList);
//        System.out.println(resList);
        System.out.println("Stored results are:");
        System.out.println(configMap.get("results"));
        return configMap;
    }



    /**
     * @param configMap the configMap to set
     */
    public void setConfigMap(HashMap<String, String> configMap) {
        this.configMap = configMap;
        setNetworked(Boolean.parseBoolean(configMap.get("networked")));
        setSearchCfg(configMap.get("dbLookUpPrg"));
        setIndexCfg(configMap.get("indexDir"));
        setDdp(Integer.parseInt(configMap.get("databaseDetectionP")));
        setReverseMode(Boolean.parseBoolean(configMap.get("reverseMode")));
        setAminoacids(configMap.get("aminoacids"));
        setCharges(configMap.get("charges"));
        setHydrophobic1(configMap.get("hydrophobic1"));
        setHydrophobic2(configMap.get("hydrophobic2"));
        setHydrophobic3(configMap.get("hydrophobic3"));
        setPairsToAvoid(configMap.get("pairsToAvoid"));
        setPairsToFilter(configMap.get("pairsToFilter"));
        setSeq(configMap.get("seq"));
        setVolScale(configMap.get("volScale"));
        setVolumes(configMap.get("volumes"));
        setID(configMap.get("ID"));
        setHp1Score(Integer.parseInt(configMap.get("Hp1Score")));
        setHp2Score(Integer.parseInt(configMap.get("Hp2Score")));
        setHp3Score(Integer.parseInt(configMap.get("Hp3Score")));
        setMotif1Score(Integer.parseInt(configMap.get("motif1Score")));
        setMotif2Score(Integer.parseInt(configMap.get("motif2Score")));
        setMotif12Score(Integer.parseInt(configMap.get("motif12Score")));
        setPairToAvoidScore(Integer.parseInt(configMap.get("pairToAvoidScore")));
        setChScore1(Integer.parseInt(configMap.get("ch1Score")));
        setChScore2(Integer.parseInt(configMap.get("ch2Score")));
        setVolScale(configMap.get("volScale"));
        setNumberOfTrials(Integer.parseInt(configMap.get("numTrial")));
        setPrintLength(Integer.parseInt(configMap.get("printLength")));
//        resList=configMap.get("results");
    }
    
    public void readConfig(String fileName) {
        File f = new File(fileName);
        MyXMLHashMap xmlConfig = new MyXMLHashMap(f);
        xmlConfig.readIn();
        setConfigMap(xmlConfig.getContent());
        System.out.println("Configuration was read from "+this.getID());
//        printResults();
    }
    
    public void writeConfig() {
        File f = new File(this.getID());
        MyXMLHashMap xmlConfig = new MyXMLHashMap(f);
        xmlConfig.setContent(getConfigMap());
        xmlConfig.writeOut();
        System.out.println("Configuration was written to "+this.getID());
        printResults();
    }
    
    public void setConfig(Config c) {
        this.setConfigMap(c.getConfigMap());
    }
    
    public void resetResults() {
        resList=null;
        configMap.put("results",null);
    }
    
    public void setResults(String results) {
//    	new Exception().printStackTrace();
        resList=results;
//        System.out.println("Config results are set to:");
//        System.out.println(resList);
    }
    
    public String getResults() {
        return resList;
    }
    
    public void printResults() {
        System.out.println(getResults());
    }



    public String getSearchCfg() {
        return searchCfg;
    }



    public void setSearchCfg(String searchCfg) {
        this.searchCfg = searchCfg;
    }



    public String getIndexCfg() {
        return indexCfg;
    }



    public void setIndexCfg(String indexCfg) {
        this.indexCfg = indexCfg;
    }

}
