/**
 * 
 */
package config;

import java.util.ArrayList;

/**
 * @author farkas
 *
 */
public class Transform {
    
    public static void main(String[] args) {
        toInput("try");
    }
    
    public static String toInput(String txt) {
    	if(txt==null) {
    		txt=" ";
    		return txt;
    	}
        char[] sc=txt.toCharArray();
        for (int i = 0; i < sc.length; i++) {
            if(sc[i]=='\n') {
                sc[i]=',';
            }
        }
        txt=String.valueOf(sc);
        return txt;
    }

    public static String toIntInput(int in) {
        return Integer.toString(in);
    }

    public static int fromIntInput(String in) {
        return Integer.parseInt(in);
    }

    public static String fromInput(String txt) {
        char[] sc=txt.toCharArray();
        ArrayList<Character> sca = new ArrayList<Character>();
        for (int i = 0; i < sc.length; i++) {
            if(sc[i]==',') {
                sc[i]='\n';
            }
            if(sc[i]!=' ') {
                sca.add(sc[i]);
            }
        }
        Character[] ssc=new Character[sca.size()];
        ssc=sca.toArray(ssc);
        sc=new char[ssc.length];
        for (int i = 0; i < ssc.length; i++) {
            sc[i]=ssc[i];
        }
        txt=String.valueOf(sc);
        return txt;
    }
    
    public static String posChargeToInput(Config cfg) {
        String out="";
        String[] charges = cfg.getCharges().split("\n");
        String[] aas = cfg.getAminoacids().split("\n");
        for (int i = 0; i < charges.length; i++) {
            if(charges[i].equals("1")) {
                if(out!="") {
                    out+=","+aas[i];
                } else {
                    out=aas[i];
                }
            }
        }
        return out;
    }

    public static void posChargeFromInput(Config config, String in) {
        String[] aas = config.getAminoacids().split("\n");
        String charge=config.getCharges();
        String[] charges = charge.split("\n");
        for (int i = 0; i < charges.length; i++) {
            if(charges[i].equals("1")) {
                charges[i]="0";
            }
        }
        for (int i = 0; i < aas.length; i++) {
            if(in.contains(aas[i])) {
                charges[i]="1";
            }
        }
        String cfgCharges="";
        for (int i = 0; i < charges.length; i++) {
            cfgCharges+=charges[i]+"\n";
        }
        config.setCharges(cfgCharges);
    }

    public static String negChargeToInput(Config cfg) {
        String out="";
        String[] charges = cfg.getCharges().split("\n");
        String[] aas = cfg.getAminoacids().split("\n");
        for (int i = 0; i < charges.length; i++) {
            if(charges[i].equals("-1")) {
                if(out!="") {
                    out+=","+aas[i];
                } else {
                    out=aas[i];
                }
            }
        }
        return out;
    }

    public static void negChargeFromInput(Config config, String in) {
        String[] aas = config.getAminoacids().split("\n");
        String charge=config.getCharges();
        String[] charges = charge.split("\n");
        for (int i = 0; i < charges.length; i++) {
            if(charges[i].equals("-1")) {
                charges[i]="0";
            }
        }
        for (int i = 0; i < aas.length; i++) {
            if(in.contains(aas[i])) {
                charges[i]="-1";
            }
        }
        charge="";
        for (int i = 0; i < charges.length; i++) {
            charge+=charges[i]+"\n";
        }
        config.setCharges(charge);
    }
    

}