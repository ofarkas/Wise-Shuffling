package config;

public class ArgumentConfig {
    
    public static void arguments(Config config, String[] args) {
        if(args==null || args.length == 0) {
            return;
        }
        System.out.println("Program arguments will be used for preconfiguration purposes.");
        for (int i = 0; i < args.length; i++) {
            String argument = args[i];
            switch (argument) {
            case "-d":
                config.distribution = true;
                System.out.println("Print distribution due to use request.");
                                continue;
            case "-c":
                config.setID(args[i+1]);
                System.out.println("Configuration file will be: "+args[i+1]);
                System.out.println("Existance of Command line argument signs command line mode, run in headless mode.");
                i++;
                continue;
            default:
                config.setSeq(argument);
                System.out.println("User request: Original sequence is: "+argument+" ("+config.getSeq()+")");
                continue;
            }
        }
        config.writeConfig();
    }

}